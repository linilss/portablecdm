import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    View,
    StyleSheet,
    FlatList,
    TouchableWithoutFeedback,
    ListView,
    ScrollView,
    ActivityIndicator,
    RefreshControl,
    Button,
    Alert,
} from 'react-native'

import {
    List,
    ListItem,
    Icon,
    Text
} from 'react-native-elements';



//Datepick
import DateTimePicker from 'react-native-modal-datetime-picker';
import { getDateTimeString } from '../../util/timeservices';
//

import TopHeader from '../top-header-view';
import OperationView from './sections/operationview';

import {
    fetchPortCallEvents,
    changeFetchReliability,
    removeError,
    toggleFavoritePortCall,
    toggleFavoriteVessel,
} from '../../actions';
import { getTimeDifferenceString } from '../../util/timeservices';
import colorScheme from '../../config/colors';

const timer = null;
const portCallId = null;

class EtaView extends Component {
    constructor(props) {
        super(props);
        // ny tid
        this.state = {
          selectedTimeType: 'ESTIMATED',
          selectedDate: new Date(),
          showDateTimePicker: false,
          showLocationSelectionModal: false,
          selectLocationFor: '',
          comment: '',
          selectedVessel: {
            name: '',
          },
        };
        //

    }
//INLAGT
    // These handle the DateTime picker
    _showDateTimePicker = () => this.setState({showDateTimePicker: true});
    _hideDateTimePicker = () => this.setState({showDateTimePicker: false});
    _handleDateTimePicked = (date) => {
      this.setState({selectedDate: date});
      this._hideDateTimePicker();
    }
//
// INLAGT
_sendPortCall() {
  const { selectedDate, selectedTimeType, comment } = this.state;
}
  _initPortCall() {
    const { selectedDate, selectedTimeType, comment } = this.state;
}
//INLAGT

  componentWillMount() {
        portCallId = this.props.portCallId;
        timer = setInterval(() => this.loadOperations, 60000);


        if (!!portCallId)
            this.loadOperations();
    }

    componentWillUnmount() {
        clearInterval(timer);
    }

    render() {
        return(
          <div>
            <View style={{flex: 1, backgroundColor: colorScheme.primaryContainerColor}}>
            <TopHeader
          title = 'ETA view'
          firstPage
          navigation={this.props.navigation}
          rightIconFunction={this.goToStateList}
            />
            <View style={styles.headerContainer}
            >
            <Text style={styles.headerText}>HEJ</Text>
            </View>
            </View>



            <View style={styles.pickerContainer}>
              <Text style={styles.selectedDateText}>{getDateTimeString(this.state.selectedDate)}</Text>
              <Button
                title="Select Time"
                buttonStyle={styles.buttonStyle}
                textStyle={{color: 'white'}}
                onPress={this._showDateTimePicker}/>
            </View>

            <DateTimePicker
              isVisible={this.state.showDateTimePicker}
              onConfirm={this._handleDateTimePicked}
              onCancel={this._hideDateTimePicker}
              mode="datetime"
            />



            // INLAGT
            <View style={styles.pickerContainer}>
              <Text style={styles.selectedDateText}>{getDateTimeString(this.state.selectedDate)}</Text>
              <Button
                title="Select Time"
                buttonStyle={styles.buttonStyle}
                textStyle={{color: 'white'}}
                onPress={this._showDateTimePicker}/>
            </View>
            // INLAGT

            </div>


        );
    }


}


const styles = StyleSheet.create ({

    headerContainer: {
        backgroundColor: colorScheme.primaryColor,
        alignItems: 'center',

    },
    headerText: {
        textAlign: 'center',
        fontSize: 20,
        color: colorScheme.primaryTextColor,
    },
    buttonStyle: {
        backgroundColor: colorScheme.primaryColor,
        marginBottom: 10,
        marginTop: 10,
        borderColor: colorScheme.primaryColor,
        borderWidth: 1,
        borderRadius: 5,
    },
    headerTitleText: {
        textAlign: 'center',
        color: colorScheme.secondaryContainerColor,
        fontSize: 12,
   },
});


export default EtaView;
